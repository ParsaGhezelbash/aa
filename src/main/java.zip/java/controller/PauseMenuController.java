package controller;

public class PauseMenuController {
    private final Controller controller;

    public PauseMenuController(Controller controller) {
        this.controller = controller;
    }

    public String saveLevel() {
        // TODO Auto-generated method
        return null;
    }

    public String restartLevel() {
        // TODO Auto-generated method
        return null;
    }
    public String showKeybinds() {
        // TODO Auto-generated method
        return null;
    }
}
